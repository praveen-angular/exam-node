import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarouselComponent } from './common-components/carousel/carousel.component';
import { DashboardHeaderComponent } from './common-components/dashboard-header/dashboard-header.component';
import { ExamsCertificationComponent } from './common-components/exams-certification/exams-certification.component';
import { LearningDevelopmentComponent } from './common-components/learning-development/learning-development.component';
import { MeasureAssessmentComponent } from './common-components/measure-assessment/measure-assessment.component';
import { MenuComponent } from './common-components/menu/menu.component';
import { RecruitmentSolutionComponent } from './common-components/recruitment-solution/recruitment-solution.component';
import { AppSettings } from './common-providers/app-settings.service';
import { ErrorMessageService } from './common-providers/error-message.service';
import { AlignHttpInterceptor } from './common-providers/http-interceptor';
import { ErrorMessageComponent } from './error-message/error-message.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { SharedModule } from './shared/shared.module';
import { ToDoComponent } from './todo/component/todo.component';
import { ToDoEffects } from './todo/todo.effects';
import { ToDoReducer } from './todo/todo.reducer';
import { AlignErrorHandlerService } from './common-providers/error-message-handler.service';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, '/assets/i18n/', '.json');
}
export function startupServiceFactory(appSetting: AppSettings): Function {
  return () => appSetting.load();
}

@NgModule({
  declarations: [
    AppComponent,
    ToDoComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    CarouselComponent,
    MenuComponent,
    MeasureAssessmentComponent,
    RecruitmentSolutionComponent,
    ExamsCertificationComponent,
    LearningDevelopmentComponent,
    DashboardHeaderComponent,
    ErrorMessageComponent
  ],
  entryComponents: [CarouselComponent],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    MatMenuModule,
    MatIconModule,
    MatToolbarModule,
    MatButtonModule,
    HttpClientModule,
    MatCardModule,
    SharedModule,
    StoreModule.forRoot({ todos: ToDoReducer }),
    EffectsModule.forRoot([ToDoEffects]),
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    AppRoutingModule
  ],
  providers: [TranslateService,
    AppSettings,
    AlignErrorHandlerService,
    ErrorMessageService,
    {
      // Provider for APP_INITIALIZER
      provide: APP_INITIALIZER,
      useFactory: startupServiceFactory,
      deps: [AppSettings],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AlignHttpInterceptor,
      deps: [ErrorMessageService],
      multi: true
    }
  ],
  bootstrap: [AppComponent],
  exports: [DashboardHeaderComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
