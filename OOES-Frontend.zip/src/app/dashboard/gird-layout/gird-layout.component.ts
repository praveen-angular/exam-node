import { Component, OnInit, Input } from '@angular/core';
import { DashboardDataModel } from '../../data-models/dashboard-data.model';

@Component({
  selector: 'app-gird-layout',
  templateUrl: './gird-layout.component.html',
  styleUrls: ['./gird-layout.component.scss']
})
export class GirdLayoutComponent implements OnInit {
  @Input() testDetails: DashboardDataModel;
  constructor() { }

  ngOnInit() {
  }

}
