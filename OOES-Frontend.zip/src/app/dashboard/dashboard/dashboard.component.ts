import { Component, OnInit } from '@angular/core';
import { DashboardDataModel } from '../../data-models/dashboard-data.model';
import { CreateTestComponent } from '../create-test/create-test.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  showGridLayout: boolean;
  showListLayout: boolean;
  public testDetails: Array<DashboardDataModel> = [{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  },{
    testId: 1,
    testName: 'Angular',
    sections: 2,
    questions: 120,
    timeInSeconds: 54
  }];
  constructor(private dialog: MatDialog) { }

  ngOnInit() {
    this.showGridLayout = true;
  }
  toggleLayout(event: string) {
    if (event === 'grid' && !this.showGridLayout) {
      this.showGridLayout = true;
      this.showListLayout = false;
    } else if (event === 'list' && !this.showListLayout) {
      this.showListLayout = true;
      this.showGridLayout = false;
    }
  }
  createTest(event: any) {
   
    const dialogRef = this.dialog.open(CreateTestComponent, {
      width: '500px',
      data: {},
      disableClose: true 
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });

  }
}
