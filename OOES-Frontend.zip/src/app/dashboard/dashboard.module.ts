import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CreateTestComponent } from './create-test/create-test.component';
import { GirdLayoutComponent } from './gird-layout/gird-layout.component';
import { ListLayoutComponent } from './list-layout/list-layout.component';
import { DashboardService } from './dashboard.service';
import { MatMenuModule } from '@angular/material/menu';
import { SharedModule } from '../shared/shared.module';
import { MatDialogModule } from '@angular/material/dialog';
const routes: Routes = [
  { path: '', component: DashboardComponent }
];


@NgModule({
  declarations: [DashboardComponent, CreateTestComponent, GirdLayoutComponent, ListLayoutComponent],
  entryComponents:[CreateTestComponent],
  imports: [
    CommonModule,
    FormsModule,
    MatMenuModule,
    MatDialogModule,
    SharedModule,
    RouterModule.forChild(routes)
  ],
  providers: [DashboardService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DashboardModule { }


