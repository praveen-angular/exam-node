import { Component, OnInit, Input } from '@angular/core';
import { DashboardDataModel } from '../../data-models/dashboard-data.model';

@Component({
  selector: 'app-list-layout',
  templateUrl: './list-layout.component.html',
  styleUrls: ['./list-layout.component.scss']
})
export class ListLayoutComponent implements OnInit {
  @Input() testDetails: DashboardDataModel;
  constructor() { }

  ngOnInit() {
  }

}
