import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface DialogData {
  animal: string;
  name: string;
}
@Component({
  selector: 'app-create-test',
  templateUrl: './create-test.component.html',
  styleUrls: ['./create-test.component.scss']
})
export class CreateTestComponent {

  constructor(public dialogRef: MatDialogRef<CreateTestComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {

  }
  onClose(){
    this.dialogRef.close();
  }
}
