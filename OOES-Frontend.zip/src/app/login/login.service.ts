import { Injectable } from "@angular/core";
import { LoginDetails } from '../data-models/login-interface';

@Injectable()

export class LoginService {


    sendLoginCredentials(loginDetials: LoginDetails) {
        
    }
}