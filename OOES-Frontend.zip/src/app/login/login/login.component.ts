import { Component, OnInit } from '@angular/core';
import { LoginDetails } from '../../data-models/login-interface';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public loginDetails: LoginDetails = { userName: null, password: null };
  constructor(private loginSer: LoginService, private router: Router) { }

  ngOnInit() {
  }
  onLoginClcked() {
    let res: any = this.loginSer.sendLoginCredentials(this.loginDetails);
    if(res.isLoggedin) {
      if(res.role === 2) {
        this.router.navigateByUrl('/dashboard');
      } else if(res.role === 1) {
        this.router.navigateByUrl('/dashboard');
      }
    } 
  }
}
