import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonsComponent } from './buttons/buttons.component';
import { CheckBoxsComponent } from './check-boxs/check-boxs.component';
import { ComboBoxsComponent } from './combo-boxs/combo-boxs.component';
import { DrapDownsComponent } from './drap-downs/drap-downs.component';
import { SecondsFormatPipe } from './pipes/seconds-format.pipe';
import { PopUpsComponent } from './pop-ups/pop-ups.component';
import { RadioButtonsComponent } from './radio-buttons/radio-buttons.component';
import { TextAreasComponent } from './text-areas/text-areas.component';
import { TextBoxsComponent } from './text-boxs/text-boxs.component';



@NgModule({
  declarations: [
    RadioButtonsComponent,
    CheckBoxsComponent,
    DrapDownsComponent,
    ComboBoxsComponent,
    TextBoxsComponent,
    TextAreasComponent,
    ButtonsComponent,
    SecondsFormatPipe,
    PopUpsComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  entryComponents: [],
  exports:[RadioButtonsComponent,
    SecondsFormatPipe,
    CheckBoxsComponent,
    DrapDownsComponent,
    ComboBoxsComponent,
    TextBoxsComponent,
    TextAreasComponent,
    ButtonsComponent,
    PopUpsComponent]
})
export class SharedModule { }
