import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-areas',
  templateUrl: './text-areas.component.html',
  styleUrls: ['./text-areas.component.scss']
})
export class TextAreasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
