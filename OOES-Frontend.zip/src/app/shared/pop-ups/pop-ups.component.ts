import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pop-ups',
  templateUrl: './pop-ups.component.html',
  styleUrls: ['./pop-ups.component.scss']
})
export class PopUpsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
