import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'secondsFormat'
})
export class SecondsFormatPipe implements PipeTransform {
  regex: any;

  transform(epochDate: any) {
    let minutes: number = Math.floor(epochDate / 60);
    let seconds: number = epochDate;
    let exactSeconds;
    if (seconds >= 60) {
      exactSeconds = seconds % 60;
    }
    if (exactSeconds !== undefined) {
      return ('0' + minutes).substr(-2) + ':' + ('0' + exactSeconds).substr(-2);

    } else {
      return ('0' + minutes).substr(-2) + ':' + ('0' + seconds).substr(-2);
    }
  }
}
