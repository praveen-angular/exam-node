import { SecondsFormatPipe } from './seconds-format.pipe';

describe('SecondsFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new SecondsFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
