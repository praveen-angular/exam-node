import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { RadioButtonModel } from '../../data-models/radio-button.model';


@Component({
  selector: 'app-radio-buttons',
  templateUrl: './radio-buttons.component.html',
  styleUrls: ['./radio-buttons.component.scss']
})
export class RadioButtonsComponent implements OnInit {
  @Input() options: RadioButtonModel;
  @Output() answerSelected = new EventEmitter<any>();
  optionsArray: any;
  constructor() { }

  ngOnInit() {
    this.optionsArray = Object.keys(this.options.options).map(i => this.options.options[i]);
  }
  changeEventInRadioButton(event: any, buttonId: any) {
    this.answerSelected.emit({ selectedOption: buttonId, questionId: this.options.questionId, type: 'radio' });
  }
}
