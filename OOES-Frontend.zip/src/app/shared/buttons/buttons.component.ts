import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-buttons',
  templateUrl: './buttons.component.html',
  styleUrls: ['./buttons.component.scss']
})
export class ButtonsComponent implements OnInit {
  @Input() type: string;
  @Input() label: string;
  @Output() onClick = new EventEmitter<any>();
  
  
  constructor() { }

  ngOnInit() {
  }
  buttonClicked(event: any) {
    this.onClick.emit(event);
  }
}
