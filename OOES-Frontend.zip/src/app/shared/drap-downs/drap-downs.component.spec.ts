import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DrapDownsComponent } from './drap-downs.component';

describe('DrapDownsComponent', () => {
  let component: DrapDownsComponent;
  let fixture: ComponentFixture<DrapDownsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DrapDownsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DrapDownsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
