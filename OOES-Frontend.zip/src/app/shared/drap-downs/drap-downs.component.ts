import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drap-downs',
  templateUrl: './drap-downs.component.html',
  styleUrls: ['./drap-downs.component.scss']
})
export class DrapDownsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
