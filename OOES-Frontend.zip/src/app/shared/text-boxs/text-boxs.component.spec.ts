import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TextBoxsComponent } from './text-boxs.component';

describe('TextBoxsComponent', () => {
  let component: TextBoxsComponent;
  let fixture: ComponentFixture<TextBoxsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TextBoxsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TextBoxsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
