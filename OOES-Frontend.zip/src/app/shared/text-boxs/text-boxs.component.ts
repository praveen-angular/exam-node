import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-boxs',
  templateUrl: './text-boxs.component.html',
  styleUrls: ['./text-boxs.component.scss']
})
export class TextBoxsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
