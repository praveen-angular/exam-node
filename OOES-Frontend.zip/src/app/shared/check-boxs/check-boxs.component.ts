import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { RadioButtonModel } from '../../data-models/radio-button.model';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-check-boxs',
  templateUrl: './check-boxs.component.html',
  styleUrls: ['./check-boxs.component.scss']
})
export class CheckBoxsComponent implements OnInit {
  @Input() options: RadioButtonModel;
  @Output() answerSelected = new EventEmitter<any>();
  optionsArray: Array<any>;
  categoriesSelected = [];
  myGroup;
  constructor(private formBuilder: FormBuilder) {
    
  }

  ngOnInit() {
    this.optionsArray = Object.keys(this.options.options).map(i => this.options.options[i]);
    this.optionsArray.forEach((data: any, i: number) => this.categoriesSelected[i] = false);
    this.myGroup = this.formBuilder.group({
      myCategory: this.formBuilder.array(this.categoriesSelected)
    });
  }
  changeEventInCheckBoxButton() {
    this.answerSelected.emit({ selectedOption: this.myGroup.get('myCategory').value, questionId: this.options.questionId, type: 'checkBox' });
  }
}
