import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckBoxsComponent } from './check-boxs.component';

describe('CheckBoxsComponent', () => {
  let component: CheckBoxsComponent;
  let fixture: ComponentFixture<CheckBoxsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckBoxsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckBoxsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
