import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComboBoxsComponent } from './combo-boxs.component';

describe('ComboBoxsComponent', () => {
  let component: ComboBoxsComponent;
  let fixture: ComponentFixture<ComboBoxsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ComboBoxsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComboBoxsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
