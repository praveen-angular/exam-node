import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combo-boxs',
  templateUrl: './combo-boxs.component.html',
  styleUrls: ['./combo-boxs.component.scss']
})
export class ComboBoxsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
