import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LiveFeedRootComponent } from './live-feed-root/live-feed-root.component';
import { Routes, RouterModule } from '@angular/router';




const routes: Routes = [
  { path: '', component: LiveFeedRootComponent }
];
@NgModule({
  declarations: [LiveFeedRootComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class LiveFeedModule { }
