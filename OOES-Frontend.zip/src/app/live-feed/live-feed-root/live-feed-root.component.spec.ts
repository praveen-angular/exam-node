import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LiveFeedRootComponent } from './live-feed-root.component';

describe('LiveFeedRootComponent', () => {
  let component: LiveFeedRootComponent;
  let fixture: ComponentFixture<LiveFeedRootComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LiveFeedRootComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LiveFeedRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
