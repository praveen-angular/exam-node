import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-feed-root',
  templateUrl: './live-feed-root.component.html',
  styleUrls: ['./live-feed-root.component.scss']
})
export class LiveFeedRootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
