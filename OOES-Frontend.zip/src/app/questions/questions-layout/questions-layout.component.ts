import { Component, OnInit, Input } from '@angular/core';
import { QuestionsDataModel } from '../../data-models/questions-data.model';

@Component({
  selector: 'app-questions-layout',
  templateUrl: './questions-layout.component.html',
  styleUrls: ['./questions-layout.component.scss']
})
export class QuestionsLayoutComponent implements OnInit {
  public hideQuestions: boolean = true;
  @Input()questions: Array<QuestionsDataModel>;
  constructor() { }

  ngOnInit() {
  }
  collapse() {
    this.hideQuestions = !this.hideQuestions;
  }
  choseQuestionType(questionId: number) {
    event.stopPropagation();
    console.log(questionId);
  }
}
