import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuestionsRootComponent } from './questions-root/questions-root.component';
import { Routes, RouterModule } from '@angular/router';
import { MatMenuModule } from '@angular/material/menu';
import { MatExpansionModule } from '@angular/material/expansion';
import { QuestionsLayoutComponent } from './questions-layout/questions-layout.component';
import { QuestionsCardComponent } from './questions-card/questions-card.component';
import { SharedModule } from '../shared/shared.module';


const routes: Routes = [
  { path: '', component: QuestionsRootComponent }
];
@NgModule({
  declarations: [QuestionsRootComponent, QuestionsLayoutComponent, QuestionsCardComponent],
  imports: [
    CommonModule,
    MatMenuModule,
    SharedModule,
    MatExpansionModule,
    RouterModule.forChild(routes)
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class QuestionsModule { }
