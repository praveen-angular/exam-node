import { Component, OnInit } from '@angular/core';
import { RadioButtonModel } from '../../data-models/radio-button.model';

@Component({
  selector: 'app-questions-card',
  templateUrl: './questions-card.component.html',
  styleUrls: ['./questions-card.component.scss']
})
export class QuestionsCardComponent implements OnInit {
  radioButtonOptions: RadioButtonModel = {
    layout: 'potrait',
    noOfOptions: 3,
    options: {
        option1: 'Correct',
        option2: 'Not Correct',
        option3: 'None of the above'
    }
  };
  constructor() { }

  ngOnInit() {
  }
  radioButtonAnswerSelected(event: any) {
    console.log(event, 'from card');

  }
}
