import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestionsRootComponent } from './questions-root.component';

describe('QuestionsRootComponent', () => {
  let component: QuestionsRootComponent;
  let fixture: ComponentFixture<QuestionsRootComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestionsRootComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestionsRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
