import { Component, OnInit } from '@angular/core';
import { QuestionsDataModel } from '../../data-models/questions-data.model';

@Component({
  selector: 'app-questions-root',
  templateUrl: './questions-root.component.html',
  styleUrls: ['./questions-root.component.scss']
})
export class QuestionsRootComponent implements OnInit {
  public questions: Array<QuestionsDataModel> = [{
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }, {
    title: 'java',
    questionId: 12
  }];
  constructor() { }

  ngOnInit() {
  }

}
