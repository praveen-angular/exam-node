export interface DashboardDataModel {
    testId: any;
    testName: string;
    sections: number;
    questions: number;
    timeInSeconds: number;
    
}