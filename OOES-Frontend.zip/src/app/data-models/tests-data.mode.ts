export interface TestsDataModel {
    title: string;
    questionId: string;
    timeInSeconds: number;
    numberOfQuestions: number;
}