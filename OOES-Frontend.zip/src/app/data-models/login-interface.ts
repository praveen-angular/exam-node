export interface LoginDetails {
    userName: string;
    password: string;
}