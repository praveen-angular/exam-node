export class AnswersModel {
    testId: any;
    userId?: any;
    questions: Array<QuestionAndAnwers>;
}
export class QuestionAndAnwers {
    correctAnswer?: any;
    typeOfQuestions: any;
    questionId: any;
    answer: any;
}