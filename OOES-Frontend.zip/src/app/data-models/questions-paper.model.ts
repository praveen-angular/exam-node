export interface QuestionPaper {
    testId: any;
    testTitle: string;
    testType: string;
    timeForTest: number;
    noOfQuestions: number;
    typeOfQuestion: string;
    questions: Array<QuestionPaperModel>;
}
export interface QuestionPaperModel {
    questionId: any;
    questionText: string;
    questionGroup: string;
    questionWeightage: number;
    questionType: RadioButtonQuestions | CheckBoxQuestions;
    compilerToBeUsed?: string;
    timeRequired?: string;
}
export interface RadioButtonQuestions {
    noOfOptions: number;
    correctAnswer: any;
    options: {
        option1?: any;
        option2?: any;
        option3?: any;
        option4?: any;
    }

}
export interface CheckBoxQuestions {
    noOfOptions: number;
    correctAnswers: [any];
    options: {
        option1?: any;
        option2?: any;
        option3?: any;
        option4?: any;
    }
}