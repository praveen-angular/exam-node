export interface QuestionsDataModel {
    questionId: number;
    title: string;
}