export class RadioButtonModel {
    layout: string;
    questionId?: any;
    noOfOptions: number;
    options: {
        option1?: any;
        option2?: any;
        option3?: any;
        option4?: any;
    }
}