import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class AlignErrorHandlerService {
      // Handle http error
      handleHttpError(error: any) {
        return Observable.throw(error);
    }

    // Handle session timeout
    errorHandler(err: any, apiName?: any, message?: any) {
       
    }

    errorLog(err: any) {
    }
}