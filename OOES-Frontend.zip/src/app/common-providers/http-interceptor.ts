import { HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap, timeout } from 'rxjs/operators';
import { ErrorMessageService } from './error-message.service';

@Injectable()
export class AlignHttpInterceptor implements HttpInterceptor {
    bodydata: any;
    method: any;
    option: any;
    constructor(private errorMessageService: ErrorMessageService) {

    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (!navigator.onLine) {
            let obj = {
                'statusCode': 503,
                'url': request.url,
                'title': 'Unable to connect',
                'message': 'Please check the internet connection and try again.'
            };
            this.errorMessageService.sendErrorMessage(obj);
            return Observable.throw({ 'error': 'network error', 'status': 503 });
        } else {
            const token = sessionStorage.getItem('access_token');
            let authReq = request.clone();
            if (token) {
                authReq = request.clone({
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + token
                    })
                });
                return next.handle(authReq).pipe(timeout(120000), tap((event: HttpEvent<any>) => {
                    if (event instanceof HttpResponse) {
                        return event;
                    }
                }, (error: any) => {

                    if (error.name && error.name === 'TimeoutError') {
                        error.status = 400;
                        let obj: any = {
                            'statusCode': 400,
                            'title': 'System error',
                            'message': 'There is an unexpected error. Please try again or contact us.'
                        };
                        this.errorMessageService.sendErrorMessage(obj);
                        return Observable.throw({ 'error': 'System Error', 'status': 400 });
                    }

                    let title, message;
                    let obj: any = {
                        'statusCode': error.status,
                        'method': this.method,
                        'url': error.url,
                        'body': this.bodydata,
                        'option': this.option,
                        'title': title,
                        'message': message
                    };
                    if (error.status === 401) {
                        obj.title = 'Permission Denied';
                        obj.message = '';
                        this.errorMessageService.sendErrorMessage(obj);
                        return Observable.throw(error);
                    } else if (error instanceof HttpErrorResponse) {

                        if (error.status === 400 || error.status === 500 || error.status === 404 || error.status === 0 || error.status === 408) {
                            obj.title = 'System error';
                            obj.message = 'There is an unexpected error. Please try again or contact us.';
                            this.errorMessageService.sendErrorMessage(obj);
                        } else if (error.status === 403) {
                            obj.title = 'Permission Denied';
                            obj.message = '';
                            this.errorMessageService.sendErrorMessage(obj);
                        } else if (error.status === 412) {
                            obj.title = 'Software outdated';
                            obj.message = 'Software is out of date. You are using an unsupported version. Go to the App Store and update the application.';
                            this.errorMessageService.sendErrorMessage(obj);
                        }
                        return Observable.throw(error);
                    }

                }));
            } else {
                let authReq = request.clone();
                authReq = request.clone({
                    headers: new HttpHeaders({
                        'Content-Type': 'application/json'
                    })
                });
                return next.handle(authReq).pipe(timeout(120000), tap((event: HttpEvent<any>) => {
                    if (event instanceof HttpResponse) {
                        return event;
                    }
                }, (error: any) => {

                }));
            }
        }
    }
}
