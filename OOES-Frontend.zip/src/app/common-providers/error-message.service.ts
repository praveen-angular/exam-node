import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class ErrorMessageService extends Subject<any> {

    private subject = new Subject<any>();

    sendErrorMessage(obj: any): void {
        this.subject.next(obj);
    }

    getErrorMessage(): Observable<any> {
        return this.subject.asObservable();
    }
}