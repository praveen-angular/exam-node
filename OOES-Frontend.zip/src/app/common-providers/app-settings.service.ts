// Angular component
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const CONFIG_URL: string = './assets/config/config.json';

@Injectable()
export class AppSettings {
    public _nodeEndPoint: any;
    private _currentEnvironment: any;
    constructor(private http: HttpClient) { }
    // This is the method want to call at bootstrap
    // Important: It should return a Promise
    load() {
        let promise = this.http.get(CONFIG_URL).toPromise();
        promise.then((config: any) => {
            this._nodeEndPoint = config.NODE_ENDPOINT;
            this.getEnvironment(config.NODE_ENDPOINT);
        });
        return promise;
    }
    // Get Current environement where application is running
    getEnvironment(temp: any) {
      
    }

    // Get DCDx backend url
    public getEnvironmentVariable() {
        return this._nodeEndPoint;
    }
}
