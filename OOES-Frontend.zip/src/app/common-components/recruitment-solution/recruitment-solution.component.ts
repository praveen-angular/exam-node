import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recruitment-solution',
  templateUrl: './recruitment-solution.component.html',
  styleUrls: ['./recruitment-solution.component.scss']
})
export class RecruitmentSolutionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
