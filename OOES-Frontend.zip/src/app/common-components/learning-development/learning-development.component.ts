import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learning-development',
  templateUrl: './learning-development.component.html',
  styleUrls: ['./learning-development.component.scss']
})
export class LearningDevelopmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
