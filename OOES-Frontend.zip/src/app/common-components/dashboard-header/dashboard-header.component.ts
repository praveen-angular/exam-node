import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard-header',
  templateUrl: './dashboard-header.component.html',
  styleUrls: ['./dashboard-header.component.scss']
})
export class DashboardHeaderComponent implements OnInit {
  dashboardLink: boolean = true;
  testLibraryLink: boolean = false;
  questionsLink: boolean = false;
  liveFeedLink: boolean = false;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  navigate(event: string) {
    if (event === 'dashboard' && !this.dashboardLink) {
      this.dashboardLink = true;
      this.testLibraryLink = false;
      this.questionsLink = false;
      this.liveFeedLink = false;
      this.router.navigateByUrl('/dashboard');
    } else if (event === 'questions' && !this.questionsLink) {
      this.dashboardLink = false;
      this.testLibraryLink = false;
      this.questionsLink = true;
      this.liveFeedLink = false;
      this.router.navigateByUrl('/questions');
    } else if (event === 'testLibrary' && !this.testLibraryLink) {
      this.dashboardLink = false;
      this.testLibraryLink = true;
      this.questionsLink = false;
      this.liveFeedLink = false;
      this.router.navigateByUrl('/testLibrary');
    } else if (event === 'liveFeed' && !this.liveFeedLink) {
      this.dashboardLink = false;
      this.testLibraryLink = false;
      this.questionsLink = false;
      this.liveFeedLink = true;
      this.router.navigateByUrl('/liveFeed');
    }
  }
}
