import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-measure-assessment',
  templateUrl: './measure-assessment.component.html',
  styleUrls: ['./measure-assessment.component.scss']
})
export class MeasureAssessmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
