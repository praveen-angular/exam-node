import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeasureAssessmentComponent } from './measure-assessment.component';

describe('MeasureAssessmentComponent', () => {
  let component: MeasureAssessmentComponent;
  let fixture: ComponentFixture<MeasureAssessmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeasureAssessmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeasureAssessmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
