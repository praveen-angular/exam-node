import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exams-certification',
  templateUrl: './exams-certification.component.html',
  styleUrls: ['./exams-certification.component.scss']
})
export class ExamsCertificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
