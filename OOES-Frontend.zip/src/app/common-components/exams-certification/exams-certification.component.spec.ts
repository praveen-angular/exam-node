import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExamsCertificationComponent } from './exams-certification.component';

describe('ExamsCertificationComponent', () => {
  let component: ExamsCertificationComponent;
  let fixture: ComponentFixture<ExamsCertificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExamsCertificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExamsCertificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
