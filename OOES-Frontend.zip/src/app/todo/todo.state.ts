import ToDo from './todo.model';

export default class ToDoState {
  ToDos: Array<ToDo>;
  ToDoError: any;
}

export const initializeState = () => {
  return { ToDos: Array<ToDo>() };
};