export default class ToDo {
    Title: string;
    IsCompleted: boolean;
}