import { Component, OnInit, Input } from '@angular/core';
import { TestsDataModel } from '../../data-models/tests-data.mode';

@Component({
  selector: 'app-test-layout',
  templateUrl: './test-layout.component.html',
  styleUrls: ['./test-layout.component.scss']
})
export class TestLayoutComponent implements OnInit {
  panelOpenState = false;
  @Input() questions: Array<TestsDataModel>;
  constructor() { }

  ngOnInit() {
    this.expandNode('test-type-panel');
    this.expandNode('categories-panel');
    this.expandNode('induestry-panel');
    this.expandNode('generic-panel');
    this.expandNode('availability-panel');
  }
  expandNode(panelClass: string) {
    let panel: any = (<HTMLElement>document.getElementsByClassName(panelClass)[0]);
    if (panel.style.display === 'block') {
      panel.style.display = 'none';
    } else {
      panel.style.display = 'block';
    }
  }
}



