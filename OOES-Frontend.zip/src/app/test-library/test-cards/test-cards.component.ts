import { Component, OnInit, Input } from '@angular/core';
import { TestsDataModel } from '../../data-models/tests-data.mode';

@Component({
  selector: 'app-test-cards',
  templateUrl: './test-cards.component.html',
  styleUrls: ['./test-cards.component.scss']
})
export class TestCardsComponent implements OnInit {
  @Input() questions: TestsDataModel;
  constructor() { }

  ngOnInit() {
  }

}
