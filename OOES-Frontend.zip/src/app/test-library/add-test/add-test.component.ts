import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-test',
  templateUrl: './add-test.component.html',
  styleUrls: ['./add-test.component.scss']
})
export class AddTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
