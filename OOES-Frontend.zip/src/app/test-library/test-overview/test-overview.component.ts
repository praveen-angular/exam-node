import { Component, OnInit } from '@angular/core';
import { TestsDataModel } from '../../data-models/tests-data.mode';

@Component({
  selector: 'app-test-overview',
  templateUrl: './test-overview.component.html',
  styleUrls: ['./test-overview.component.scss']
})
export class TestOverviewComponent implements OnInit {

  public questions: Array<TestsDataModel> = [{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },{
    title: 'how to implement array',
    questionId: '123',
    timeInSeconds: 10,
    numberOfQuestions: 10
  },];
  constructor() { }

  ngOnInit() {
  }

}

