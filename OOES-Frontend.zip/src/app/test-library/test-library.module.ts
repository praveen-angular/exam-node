import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestOverviewComponent } from './test-overview/test-overview.component';
import { AddTestComponent } from './add-test/add-test.component';
import { Routes, RouterModule } from '@angular/router';
import { MatMenuModule } from '@angular/material/menu';
import { TestCardsComponent } from './test-cards/test-cards.component';
import { TestLayoutComponent } from './test-layout/test-layout.component';


const routes: Routes = [
  { path: '', component: TestOverviewComponent }
];
@NgModule({
  declarations: [TestOverviewComponent, AddTestComponent, TestCardsComponent, TestLayoutComponent],
  imports: [
    CommonModule,
    MatMenuModule,
    RouterModule.forChild(routes)
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TestLibraryModule { }
