import { Component, OnInit } from '@angular/core';
import { PerformTestService } from '../perform-test.service';

@Component({
  selector: 'app-test-result',
  templateUrl: './test-result.component.html',
  styleUrls: ['./test-result.component.scss']
})
export class TestResultComponent implements OnInit {
  public testResult: any;
  constructor(private performTestSer: PerformTestService) { }

  ngOnInit() {
    this.testResult = this.performTestSer.getTestSummary();
  }

}
