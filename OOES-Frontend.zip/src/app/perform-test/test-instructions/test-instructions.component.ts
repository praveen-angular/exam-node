import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-test-instructions',
  templateUrl: './test-instructions.component.html',
  styleUrls: ['./test-instructions.component.scss']
})
export class TestInstructionsComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  beginTest() {
   this.router.navigateByUrl('/performTest/questionPaper');
  }
}
