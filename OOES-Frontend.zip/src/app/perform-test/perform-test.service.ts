import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { AlignErrorHandlerService } from '../common-providers/error-message-handler.service';
import { AnswersModel } from '../data-models/answer.model';
import { QuestionPaper } from '../data-models/questions-paper.model';

@Injectable()

export class PerformTestService {
    storeTestResult = new AnswersModel();
    storeQuestionPaper: QuestionPaper;
    timeTakenForTest: number;
    constructor(private http: HttpClient, private errorHandler: AlignErrorHandlerService) { }

    getTest(userId?: any) {
        return this.http.get('../../assets/questions.json').pipe(catchError((error: Response) => this.errorHandler.handleHttpError(error)));
    }
    storeTestInfo(answerDetails: any, questionDetails: QuestionPaper, timeSpent: number) {
        this.storeTestResult = answerDetails;
        this.storeQuestionPaper = questionDetails;
        this.timeTakenForTest = timeSpent;
    }
    getTestSummary() {
        let noOfAnswers = this.storeTestResult.questions.length;
        return { answersGiven: noOfAnswers, questionsGiven: this.storeQuestionPaper.noOfQuestions, timeTaken: this.timeTakenForTest}
    }
}