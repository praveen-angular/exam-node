import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-start-test',
  templateUrl: './start-test.component.html',
  styleUrls: ['./start-test.component.scss']
})
export class StartTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
