import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-summary',
  templateUrl: './test-summary.component.html',
  styleUrls: ['./test-summary.component.scss']
})
export class TestSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
