import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestInstructionsComponent } from './test-instructions/test-instructions.component';
import { StartTestComponent } from './start-test/start-test.component';
import { QuestionPaperComponent } from './question-paper/question-paper.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { FormsModule } from '@angular/forms';
import { PerformTestService } from './perform-test.service';
import { HttpClientModule } from '@angular/common/http';
import { NgxPaginationModule } from 'ngx-pagination';
import { TestSummaryComponent } from './test-summary/test-summary.component';
import { TestResultComponent } from './test-result/test-result.component';

const routes: Routes = [
  { path: '', component: TestInstructionsComponent },
  { path: 'startTest', component: StartTestComponent },
  { path: 'questionPaper', component: QuestionPaperComponent },
  { path: 'testResult', component: TestResultComponent },
  { path: 'testSummary', component: TestSummaryComponent }
];
@NgModule({
  declarations: [TestInstructionsComponent, StartTestComponent, QuestionPaperComponent, TestSummaryComponent, TestResultComponent],
  imports: [
    CommonModule,
    SharedModule,
    NgxPaginationModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forChild(routes)
  ],
  providers: [PerformTestService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PerformTestModule { }
