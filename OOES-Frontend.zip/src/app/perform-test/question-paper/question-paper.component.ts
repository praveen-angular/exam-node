import { Component, OnInit, HostListener } from '@angular/core';
import { PerformTestService } from '../perform-test.service';
import { QuestionPaper } from '../../data-models/questions-paper.model';
import { interval } from 'rxjs';
import { AnswersModel } from '../../data-models/answer.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-question-paper',
  templateUrl: './question-paper.component.html',
  styleUrls: ['./question-paper.component.scss']
})
export class QuestionPaperComponent implements OnInit {
  public questionPaperDetails: QuestionPaper;
  public testTime: any = 0;
  public answerModel = new AnswersModel();
  public questionsAnswered: number = 0;
  constructor(private getTestInformation: PerformTestService, private router: Router) { }

  ngOnInit() {
    this.getTestInformation.getTest().subscribe((data: any) => {
      this.questionPaperDetails = data.test;
      this.answerModel.testId = this.questionPaperDetails.testId;
      console.log(this.questionPaperDetails);
    });


    interval(1000).subscribe(x => {
      this.testTime = this.testTime + 1;
      if ((this.questionPaperDetails.timeForTest * 60) === this.testTime) {
        console.log('test Completed');
        this.getTestInformation.storeTestInfo(this.answerModel, this.questionPaperDetails, this.testTime / 60);
        this.router.navigateByUrl('/performTest/testResult');
      }
    });
  }
  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler($event: any) {
    $event.returnValue = 'Your data will be lost!';
  }
  radioButtonAnswerSelected(event: any) {
    let dataInserted: boolean = false;
    if (this.answerModel.questions) {
      this.answerModel.questions.forEach((data: any, index: number) => {
        if (data.questionId === event.questionId) {
          this.answerModel.questions[index].answer = event.selectedOption;
          dataInserted = true;
        }
      });
      if (!dataInserted) {
        this.answerModel.questions.push({
          typeOfQuestions: event.type,
          questionId: event.questionId,
          answer: event.selectedOption
        });
      }
    } else {
      if (!dataInserted) {
        this.answerModel.questions = [{
          typeOfQuestions: event.type,
          questionId: event.questionId,
          answer: event.selectedOption
        }];
      }
    }
    this.questionsAnswered = this.answerModel.questions.length;
  }
  CheckBoxButtonAnswerSelected(event: any) {
    let dataInserted: boolean = false;
    if (this.answerModel.questions) {
      this.answerModel.questions.forEach((data: any, index: number) => {
        if (data.questionId === event.questionId) {
          this.answerModel.questions[index].answer = event.selectedOption;
          dataInserted = true;
        }
      });
      if (!dataInserted) {
        this.answerModel.questions.push({
          typeOfQuestions: event.type,
          questionId: event.questionId,
          answer: event.selectedOption
        });
      }
    } else {
      if (!dataInserted) {
        this.answerModel.questions = [{
          typeOfQuestions: event.type,
          questionId: event.questionId,
          answer: event.selectedOption
        }];
      }
    }
    this.questionsAnswered = this.answerModel.questions.length;
    console.log(this.answerModel);
  }

}
