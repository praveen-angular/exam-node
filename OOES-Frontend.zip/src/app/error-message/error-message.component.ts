import { Component, OnInit } from '@angular/core';
import { ErrorMessageService } from '../common-providers/error-message.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-error-message',
  templateUrl: './error-message.component.html',
  styleUrls: ['./error-message.component.scss']
})
export class ErrorMessageComponent implements OnInit {
  public errorMessageSubscription: Subscription;
  constructor(private errorMesasgeService: ErrorMessageService) { }

  ngOnInit() {
    this.errorMessageSubscription = this.errorMesasgeService.getErrorMessage().subscribe((error: any) => {

    });
  }

}
